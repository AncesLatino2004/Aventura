package JocNau;

public class Enemy {
    private String name;
    private int turnCounter; // Contador para los turnos
    private Room currentRoom; // La habitación en la que está el enemigo
    private int moveCounter;  // Contador para mover al enemigo cada 2 turnos

    public Enemy(String name, Room startRoom) {
        this.name = "Gonzalin";
        this.currentRoom = startRoom; // El enemigo comienza en una habitación específica
        this.turnCounter = 0;
        this.moveCounter = 0;
    }

    public String getName() {
        return name;
    }

    public Room getCurrentRoom() {
        return currentRoom;
    }

    // Método para que el enemigo ataque al jugador
    public void attack(Player player) {
        System.out.println(name + " ataca a " + player.getName() + "!");
        System.out.println("Dentro de 7 turnos morirás...");
        gameOver();
    }

    // El enemigo se mueve cada 2 movimientos del jugador
    public void checkMove(Player player, Map map) {
        moveCounter++;
        if (moveCounter == 2) {
            moveTowardsPlayer(player, map); // Mover el enemigo hacia el jugador
            moveCounter = 0; // Reiniciar el contador de movimiento
        }
    }

    // El enemigo se mueve hacia la habitación del jugador
    public void moveTowardsPlayer(Player player, Map map) {
        Room playerRoom = player.getCurrentRoom();

        // Verificar las salidas posibles y mover al enemigo hacia el jugador
        for (int i = 0; i < 4; i++) {
            int exit = currentRoom.getExit(getDirectionFromIndex(i));
            if (exit != -1 && map.getRoom(exit) == playerRoom) {
                currentRoom = playerRoom;
                System.out.println(name + " se ha movido de habitacion");
                return;
            }
        }

        // Si no está en una habitación adyacente, buscar una dirección para moverse
        for (int i = 0; i < 4; i++) {
            int exit = currentRoom.getExit(getDirectionFromIndex(i));
            if (exit != -1) {
                currentRoom = map.getRoom(exit);
                System.out.println(name + " se ha movido a: " + currentRoom.getName());
                return;
            }
        }
    }

    // Obtener la dirección como cadena según el índice del array de salidas
    private String getDirectionFromIndex(int index) {
        switch (index) {
            case 0: return "up";
            case 1: return "down";
            case 2: return "left";
            case 3: return "right";
            default: return "";
        }
    }

    // Simulación de la cuenta regresiva hasta el "game over"
    public void gameOver() {
        turnCounter++;
        if (turnCounter >= 7) {
            System.out.println("GAME OVER");
            System.exit(0);
        }
    }
}
