package JocNau;

import java.util.Scanner;

public class AdventureGame {
    public static void main(String[] args) {
        // Crear el mapa
        Map m;
        // Crear al jugador y ponerlo en la habitación inicial
        Player player = new Player("Hero", m.getRoom(8));
        Enemy enemy = new Enemy("Gonzalin",m.getRoom(0));
        // Inicializar el escáner para entrada del usuario
        Scanner scanner = new Scanner(System.in);
        String input;

        // Ciclo del juego
        while (true) {
            System.out.println("\nEstás en: " + player.getCurrentRoom().getName());
            System.out.println(player.getCurrentRoom().getDescription());
            System.out.println("¿Hacia dónde quieres ir? (up, down, left, right) o 'quit' para salir:");

            input = scanner.nextLine();

            if (input.equalsIgnoreCase("quit")) {
                System.out.println("¡Gracias por jugar!");
                break;
            }

            // Intentar mover al jugador en la dirección especificada
            player.move(input, m);
        }

        scanner.close();
    }
}
