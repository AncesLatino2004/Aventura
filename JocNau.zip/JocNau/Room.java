package JocNau;



import java.util.ArrayList;

public class Room {
    private String name;
    private String description;
    private int[] exits; // [arriba, abajo, izquierda, derecha]
    private ArrayList<Item> items;

    public Room(String name, String description) {
        this.name = name;
        this.description = description;
        this.exits = new int[4]; // Inicializamos con conexiones no definidas
        this.items = new ArrayList<>(); // Lista de objetos en la sala
    }

    public void setExits(int up, int down, int left, int right) {
        exits[0] = up;
        exits[1] = down;
        exits[2] = left;
        exits[3] = right;
    }

    public int getExit(String direction) {
        switch (direction.toLowerCase()) {
            case "up": return exits[0];
            case "down": return exits[1];
            case "left": return exits[2];
            case "right": return exits[3];
            default: return -1; // Salida no válida
        }
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public ArrayList<Item> getItems() {
        return items;
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public void removeItem(Item item) {
        items.remove(item);
    }

    public void showItems() {
        if (items.size() > 0) {
            System.out.println("Los siguientes objetos están en la sala:");
            for (Item item : items) {
                System.out.println("- " + item.getName());
            }
        } else {
            System.out.println("No hay objetos en esta sala.");
        }
    }
}


